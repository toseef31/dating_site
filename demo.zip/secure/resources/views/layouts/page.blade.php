<!DOCTYPE html>
<html>
<head>
    @include('partials.header')
    @yield('stylesheet')
</head>
<body>
<div class="pages">
    <div class="header-page">
        <div class="container">
            <div class="main">
                {!! isset($page_title)?$page_title: '&nbsp;' !!}
            </div>
        </div>
    </div>
    <div class="container">
        @include('partials.sidebar')
        <div class="main">
            @yield('content')
        </div>
    </div>
    @include('partials.footer')
</div>
<script>
    var ajax_url = '{!! route('ajax') !!}';
</script>
<script src="{!! url('assets/js/app.js') !!}"></script>
@yield('javascript')
</body>
</html>

@extends('admin.layout')
@section('title')
    <title>Dashboard</title>
@endsection
@section('content')

@endsection
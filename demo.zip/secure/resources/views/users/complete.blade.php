@extends('layouts.welcome')
@section('content')

@endsection
<div id="message-box-{!! $conversation->id !!}" class="h-100">
    <div class="title-conversation">
        {!! auth()->id() === $conversation->sender_id ? fullname($conversation->receive->firstname, $conversation->receive->lastname, $conversation->receive->username) : fullname($conversation->sender->firstname, $conversation->sender->lastname, $conversation->sender->username) !!}
    </div>
    <div class="list-messages">
        <ul class="list-unstyled mb-0">
            @if($conversation->messages()->count())
                @if($conversation->messages()->count() > 20)
                    <li class="load_more_message" data-id="{!! $conversation->id !!}" data-page="1"><span>Load more</span></li>
                @endif
                @foreach(collect($conversation->messages()->get()->take(20))->reverse() as $message)
                    {!! $message->seen() !!}
                    @include('messages.message')
                @endforeach
            @endif
        </ul>
        <div class="write-message{!! auth()->id() == $conversation->sender_id && $conversation->waiting == 1 && !empty($conversation->last_message)?' waiting':'' !!}">
            <input data-id="{!! $conversation->id !!}" placeholder="Type your message..." class="message-input">
        </div>
    </div>
</div>

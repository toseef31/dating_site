@extends('layouts.page')
@section('javascript')
    <script>
        jQuery(document).ready(function ($) {
            var id = 0;
            if($('.conversation-item.active').length){
                id = $('.conversation-item.active').attr('data-id');
            }
            var token = $('meta[name=csrf_token]').attr('content');
            setInterval(function(){
               $.ajax({
                   url: ajax_url,
                   data: {action: 'check_messages', _token: token, id: id},
                   dataType: 'JSON',
                   type: 'POST',
                   success: function (res) {
                       if(res.status === 'success'){
                           $.each(res.result, function(id, item){
                               if($('#conversation-'+item.id).length){
                                   $('#conversation-'+item.id).find('p').html(item.last_message);
                                   $('#conversation-'+item.id).each(function(){
                                      $(this).parent().prepend(this);
                                   });
                                   if($('#message-box-'+item.id).length){
                                       if(item.messages.length){
                                           $.each(item.messages, function(im, message){
                                               if(!$('#message-'+message.id).length){
                                                   $('#message-box-'+item.id+' .list-messages ul .mCSB_container').append(message.html);
                                                   $('#message-box-'+item.id+' .list-messages ul').mCustomScrollbar("scrollTo","bottom",{scrollInertia:0});
                                               }
                                           });
                                       }
                                   }
                               }
                               else{
                                   $('.list-conversations ul').prepend(item.html);
                                   $('#conversation-'+item.id).each(function(){
                                       $(this).parent().prepend(this);
                                   });
                               }
                               document.getElementById('message_audio').play();
                           })
                       }
                   }
               })
            }, 3000);
        });
    </script>
@endsection
@section('content')
    <div class="conversations clearfix">
        <div class="float-left list-conversations">
            <div class="search-conversation">
                <input type="text">
                <i class="fas fa-search"></i>
            </div>
            <ul class="list-unstyled mb-0">
                @if($conversations->count())
                    @foreach($conversations as $key=>$conv)
                        @include('messages.item')
                    @endforeach
                @endif
            </ul>
        </div>
        <div class="float-left message-box">
            <?php
            if(!isset($conversation)){
                $conversation = $conversations->first();
            }
            ?>
            @if($conversation)
                @include('messages.conversation')
            @endif
        </div>
    </div>
@endsection

<?php $__env->startSection('content'); ?>
    <div class="page-title text-uppercase">
        Search Filter
    </div>
    <div class="filter shadow-sm p-3 border bg-white">
        <form class="form-inline" action="" id="formFilter">
            <strong>I am a&nbsp;</strong>
            <div class="custom-control custom-radio custom-control-inline">
                <input<?php echo request()->get('gender') == 'male' || (auth()->check() && auth()->user()->gender == '1') || !auth()->check()?' checked':''; ?> type="radio" value="male" id="gender-filter-male" name="gender" class="custom-control-input">
                <label class="custom-control-label" for="gender-filter-male">Male</label>
            </div>
            <div class="custom-control custom-radio custom-control-inline">
                <input<?php echo request()->get('gender') == 'female' || auth()->check() && auth()->user()->gender == '2' ?' checked':''; ?> type="radio" value="female" id="gender-filter-female" name="gender" class="custom-control-input">
                <label class="custom-control-label" for="gender-filter-female">Female</label>
            </div>
            <strong>Seeking a&nbsp;</strong>
            <div class="custom-control custom-checkbox custom-control-inline">
                <input<?php echo in_array(1,$default_preference)?' checked':''; ?> type="checkbox" value="male" id="seeking-filter-male" name="seeking[]" class="custom-control-input">
                <label class="custom-control-label" for="seeking-filter-male">Male</label>
            </div>
            <div class="custom-control custom-checkbox custom-control-inline">
                <input<?php echo in_array(2,$default_preference)?' checked':''; ?> type="checkbox" value="female" id="seeking-filter-female" name="seeking[]" class="custom-control-input">
                <label class="custom-control-label" for="seeking-filter-female">Female</label>
            </div>
            <select class="custom-select custom-select-sm w-25" name="country" id="filter-country">
                <option value="">Country</option>
                <?php $__currentLoopData = countries(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option<?php echo request()->get('country') == $key ? ' selected':''; ?> value="<?php echo $key; ?>"><?php echo $country; ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <button class="btn btn-sm btn-primary ml-2">Search</button>
        </form>
    </div>
    <div class="search-content mt-3 mb-3">
        <?php if(count($users)): ?>
            <div class="row mb-3">
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3">
                    <a href="<?php echo route('profile',['username'=>$user->username]); ?>">
                        <div class="user-item shadow-sm rounded effect" style="background-image: url('<?php echo avatar($user->avatar, $user->gender); ?>')">
                            <span class="photos"><i class="fas fa-camera"></i> <?php echo $user->photos()->count(); ?></span>
                            <span class="fullname"><?php echo fullname($user->fullname, $user->username); ?></span>
                            <span class="address"><?php echo fulladdress($user->address, $user->country); ?></span>
                        </div>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php else: ?>
        <?php endif; ?>
        <?php echo $users->onEachSide(5)->links(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\cloud\secure\resources\views/landing.blade.php ENDPATH**/ ?>
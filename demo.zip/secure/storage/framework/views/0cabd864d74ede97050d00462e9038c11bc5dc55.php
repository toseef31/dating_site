<div class="row position-relative">
    <span class="close-view-photo position-absolute">&times;</span>
    <div class="col-md-8">
        <div class="full_photo d-flex align-items-center"><img src="<?php echo url($photo->file); ?>"></div>
    </div>
    <div class="col-md-4 view-photo-right">
        <div class="user-info">
            <div class="media">
                <img src="<?php echo avatar($photo->user->avatar, $photo->user->gender); ?>">
                <h3><a href="<?php echo route('profile',['username'=>$photo->user->username]); ?>"><?php echo fullname($photo->user->fullname, $photo->user->username); ?></a></h3>
            </div>
        </div>
        <div class="comments">
            <ul class="list-unstyled m-0">
                <?php if($photo->comments()->count()): ?>
                    <?php $__currentLoopData = $photo->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $__env->make('photo.comment', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </ul>
            <div class="like-photo clearfix">
                <?php if($photo->likes()->count() && auth()->check() && in_array(auth()->id(), collect($photo->likes()->get())->pluck('id')->all())): ?>
                    <i class="fas fa-heart" data-id="<?php echo $photo->id; ?>" id="love-photo"></i>
                <?php else: ?>
                    <i class="far fa-heart" data-id="<?php echo $photo->id; ?>" id="love-photo"></i>
                <?php endif; ?>
                <span><?php echo $photo->likes()->count()?$photo->likes()->count():''; ?></span>
            </div>
            <textarea data-id="<?php echo $photo->id; ?>" class="write-comment" placeholder="Comment on this photo"></textarea>
        </div>
    </div>
</div>
<?php /**PATH D:\Xampp\htdocs\cloud\secure\resources\views/photo/view.blade.php ENDPATH**/ ?>
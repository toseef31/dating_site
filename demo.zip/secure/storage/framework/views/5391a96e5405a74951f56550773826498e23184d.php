<?php $__env->startSection('title'); ?>
    <title>Pages</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <h3 class="clearfix">Pages<a class="btn btn-info float-right" href="<?php echo route('adminaddpage'); ?>"><i class="fas fa-plus"></i> Add New</a></h3>
    <div class="table-responsive mt-3">
        <table class="table table-bordered table-striped">
            <thead>
            <tr>
                <th>Title</th>
                <th>Created At</th>
                <th>Action</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <a href="<?php echo route('page',['slug'=>$page->slug]); ?>"><?php echo $page->title; ?></a>
                    </td>
                    <td><?php echo $page->created_at; ?></td>
                    <td>
                        <a class="btn btn-info btn-sm" href="<?php echo route('adminaddpage',['id'=>$page->id]); ?>"><i class="fas fa-edit"></i> Edit</a>
                        <a onclick="return confirm('Are you sure?')" class="btn btn-warning btn-sm" href="<?php echo route('admindeletepage',['id'=>$page->id]); ?>"><i class="fas fa-trash"></i> Delete</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mycloudd/public_html/demo.myclouddate.com/secure/resources/views/admin/pages.blade.php ENDPATH**/ ?>
<?php $__env->startSection('javascript'); ?>
    <script>
        function showUserLocation(){
            var userlocation = {lat: <?php echo $user->lat; ?>, lng: <?php echo $user->lng; ?>};
            var map = new google.maps.Map(
                document.getElementById('usermap'), {zoom: 15, center: userlocation, zoomControl: false, mapTypeControl: false, scaleControl: false});
            // The marker, positioned at Uluru
            var icon = {
                url: '<?php echo avatar($user->avatar, $user->gender); ?>',
                size: new google.maps.Size(50, 50),
                origin: new google.maps.Point(0, 0),
                scaledSize: new google.maps.Size(50, 50),
                shape:{coords:[25,25,25],type:'circle'},
                optimized:false
            };
            var myoverlay = new google.maps.OverlayView();
            myoverlay.draw = function () {
                this.getPanes().markerLayer.id='markerLayer';
            };
            myoverlay.setMap(map);
            var marker = new google.maps.Marker({
                position: userlocation,
                map: map,
                title: '<?php echo fullname($user->firstname, $user->lastname, $user->username); ?>',
                icon: icon
            });
        }
    </script>
    <script src="https://maps.googleapis.com/maps/api/js?key=<?php echo env('GOOGLE_PLACE_API','AIzaSyBjVRkL8MOLaVd-fjloQguTIQDLAAzA4w0'); ?>&callback=showUserLocation" async defer></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="profile">
        <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm" id="profile-header">
            <div class="container">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse">
                    <ul class="navbar-nav mr-auto">
                        <?php if((auth()->check() && auth()->user()->id != $user->id) || !auth()->check()): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="javascript:void(0)">
                                <button data-id="<?php echo $user->id; ?>" data-type="like" class="btn-love<?php echo auth()->check() && auth()->user()->likes()->where('id', $user->id)->first() && auth()->user()->likes()->where('id', $user->id)->first()->pivot->type == 'like' ? ' active': '';?>"><i class="fas fa-heart"></i></button>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo $nextuser ? route('profile',['username'=>$nextuser->username]) : route('landing'); ?>">
                                <button class="btn-unlove"><i class="fas fa-times"></i></button>
                            </a>
                        </li>
                        <?php endif; ?>
                        <li class="nav-item">
                            <p class="mb-1">
                                <span class="text-uppercase"><?php echo fullname($user->firstname, $user->lastname, $user->username); ?></span>
                                <span class="user-info">
                                    <?php echo Carbon\Carbon::parse($user->birthday)->age; ?>yr <?php echo $user->gender == 1 ? 'Male' : 'Female'; ?>

                                    | Seeking <?php echo $user->preference == 1 ? 'Male' : ($user->preference == 2 ? 'Female': 'Male, Female'); ?>

                                </span>
                            </p>
                            <p class="user-address"><i class="fas fa-map-marker-alt"></i> <?php echo fulladdress($user->address, $user->country); ?></p>
                        </li>
                    </ul>
                    <?php if((auth()->check() && auth()->user()->id != $user->id) || !auth()->check()): ?>
                    <span class="navbar-text">
                        <a href="<?php echo route('chat',['id'=>$user->id]); ?>" class="btn btn-light btn-sm border rounded-pill">Chat&nbsp;&nbsp;&nbsp;<i class="fas fa-comment"></i></a>
                    </span>
                    <?php endif; ?>
                </div>
            </div>
        </nav>
        <div class="container">
            <?php if(!auth()->check()): ?>
                <?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="main">
            <?php endif; ?>
            <?php if($user->photos()->count() || (auth()->check() && auth()->user()->id == $user->id) ): ?>
                <p class="page-title text-uppercase mb-1 clearfix">
                    Public Photos
                    <a class="float-right" href="<?php echo route('userphoto',['username'=>$user->username]); ?>">View All</a>
                </p>
                <div class="row users-photo mb-3">
                    <?php
                    if((auth()->check() && auth()->user()->id == $user->id)){
                        $photos = $user->photos()->orderBy('updated_at','DESC')->get()->take(5);
                    }
                    else{
                        $photos = $user->photos()->orderBy('updated_at','DESC')->get()->take(6);
                    }
                    ?>
                    <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-2">
                            <div data-id="<?php echo $photo->id; ?>" data-url="<?php echo url($photo->file); ?>" class="photo-item view-photo border" style="background-image: url('<?php echo url($photo->thumb); ?>')">
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if((auth()->check() && auth()->user()->id == $user->id)): ?>
                        <div class="col-md-2">
                            <div class="photo-item add-photo">
                                <i class="fas fa-camera"></i>
                                <p>Add Photo</p>
                            </div>
                        </div>
                    <?php endif; ?>
                    <div class="modal fade" id="modalUpload" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Writing something</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <div class="upload-progress progress">
                                        <div class="progress-bar bg-primary progress-bar-striped progress-bar-animated" role="progressbar" style="width: 0%" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                    <form id="formUpload" action="<?php echo route('upload_photo'); ?>" enctype="multipart/form-data" method="post">
                                        <?php echo csrf_field(); ?>

                                        <input id="upload-photo" name="file" type="file" accept="image/*" class="d-none">
                                        <div class="form-group">
                                            <textarea class="form-control" placeholder="Writing something for photo" name="description" rows="3"></textarea>
                                        </div>
                                        <div class="form-group">
                                            <button class="btn btn-sm btn-primary btn-block" type="submit">Upload</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
                <p class="page-title text-uppercase mb-1">Location</p>
                <div id="usermap"></div>
                <p class="page-title text-uppercase mb-1 mt-3">About Me</p>
                <div id="user-about" class="text-muted"><?php echo $user->about; ?></div>
                <p class="page-title text-uppercase mb-1 mt-3">Preference</p>
                <div id="user-preference">
                    <?php $__currentLoopData = $user->interests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $interest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="javascript:void(0)" class="user-interest"><?php echo $interest->text; ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php if(!auth()->check()): ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mycloudd/public_html/demo.myclouddate.com/secure/resources/views/users/profile.blade.php ENDPATH**/ ?>
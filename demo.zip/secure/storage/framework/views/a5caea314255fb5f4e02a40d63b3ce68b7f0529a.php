<?php $__env->startSection('javascript'); ?>
    <script>
        jQuery(document).ready(function ($) {
            var id = 0;
            if($('.conversation-item.active').length){
                id = $('.conversation-item.active').attr('data-id');
            }
            var token = $('meta[name=csrf_token]').attr('content');
            setInterval(function(){
               $.ajax({
                   url: ajax_url,
                   data: {action: 'check_messages', _token: token, id: id},
                   dataType: 'JSON',
                   type: 'POST',
                   success: function (res) {
                       if(res.status === 'success'){
                           $.each(res.result, function(id, item){
                               if($('#conversation-'+item.id).length){
                                   $('#conversation-'+item.id).find('p').html(item.last_message);
                                   $('#conversation-'+item.id).each(function(){
                                      $(this).parent().prepend(this);
                                   });
                                   if($('#message-box-'+item.id).length){
                                       if(item.messages.length){
                                           $.each(item.messages, function(im, message){
                                               if(!$('#message-'+message.id).length){
                                                   $('#message-box-'+item.id+' .list-messages ul .mCSB_container').append(message.html);
                                                   $('#message-box-'+item.id+' .list-messages ul').mCustomScrollbar("scrollTo","bottom",{scrollInertia:0});
                                               }
                                           });
                                       }
                                   }
                               }
                               else{
                                   $('.list-conversations ul').prepend(item.html);
                                   $('#conversation-'+item.id).each(function(){
                                       $(this).parent().prepend(this);
                                   });
                               }
                               document.getElementById('message_audio').play();
                           })
                       }
                   }
               })
            }, 3000);
        });
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="conversations clearfix">
        <div class="float-left list-conversations">
            <div class="search-conversation">
                <input type="text">
                <i class="fas fa-search"></i>
            </div>
            <ul class="list-unstyled mb-0">
                <?php if($conversations->count()): ?>
                    <?php $__currentLoopData = $conversations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$conv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $__env->make('messages.item', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </ul>
        </div>
        <div class="float-left message-box">
            <?php
            if(!isset($conversation)){
                $conversation = $conversations->first();
            }
            ?>
            <?php if($conversation): ?>
                <?php echo $__env->make('messages.conversation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mycloudd/public_html/demo.myclouddate.com/secure/resources/views/messages/all.blade.php ENDPATH**/ ?>
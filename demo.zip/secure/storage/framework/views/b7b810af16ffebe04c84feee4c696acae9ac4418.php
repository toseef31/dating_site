<?php $__env->startSection('javascript'); ?>
    <script src="https://maps.googleapis.com/maps/api/js?key=<?php echo env('GOOGLE_PLACE_API','AIzaSyBjVRkL8MOLaVd-fjloQguTIQDLAAzA4w0'); ?>&libraries=places&callback=initMap" async defer></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="user-setting mt-2">
    <?php if($errors->any()): ?>
        <div class="alert alert-danger alert-dismissible ">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>
    <?php if(session()->has('success_msg')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Success!</strong> <?php echo session()->get('success_msg'); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            <?php echo session()->forget('success_msg'); ?>

        </div>
    <?php endif; ?>
    <?php if(session()->has('error_msg')): ?>
        <div class="alert alert-warning alert-dismissible fade show" role="alert">
            <strong>Warning!</strong> <?php echo session()->get('error_msg'); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            <?php echo session()->forget('error_msg'); ?>

        </div>
    <?php endif; ?>
    <form action="" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label>First Name</label>
                    <input class="form-control second bg-white" name="firstname" value="<?php echo $user->firstname; ?>">
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label>Last Name</label>
                    <input class="form-control second bg-white" name="lastname" value="<?php echo $user->lastname; ?>">
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label>Email</label>
                    <input class="form-control second bg-white" readonly value="<?php echo $user->email; ?>">
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label>Age</label>
                    <div class="row">
                        <div class="col-md-4">
                            <select autocomplete="off" class="form-control second bg-white" name="day" required>
                                <option value="">Day</option>
                                <?php for($i=1;$i <32; $i++): ?>
                                    <option<?php echo (date('j', strtotime($user->birthday)) == $i) ? ' selected="selected"': ''; ?> value="<?php echo strlen($i) == 1 ? '0'.$i:$i; ?>" ><?php echo $i; ?></option>
                                <?php endfor; ?>
                            </select>
                            <i class="fa fa-chevron-down"></i>
                        </div>
                        <div class="col-md-4">
                            <select autocomplete="off" class="form-control second bg-white" name="month" required>
                                <option value="">Month</option>
                                <?php $__currentLoopData = months(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option<?php echo date('n', strtotime($user->birthday)) == $key+1 ? ' selected': ''; ?> value="<?php echo strlen($key+1) == 1?'0'.($key+1):$key+1; ?>"><?php echo $month; ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <i class="fa fa-chevron-down"></i>
                        </div>
                        <div class="col-md-4">
                            <select autocomplete="off" class="form-control second bg-white" name="year" required>
                                <option value="">Year</option>
                                <?php for($i=date('Y')-10;$i >= 1920; $i--): ?>
                                    <option<?php echo date('Y', strtotime($user->birthday)) == $i? ' selected':''; ?> value="<?php echo $i; ?>"><?php echo $i; ?></option>
                                <?php endfor; ?>
                            </select>
                            <i class="fa fa-chevron-down"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label>Address</label>
                    <input id="register-address" class="form-control second bg-white" name="address" value="<?php echo $user->address; ?>">
                    <input type="hidden" value="<?php echo $user->lat; ?>" name="lat" id="register-lat">
                    <input type="hidden" value="<?php echo $user->lng; ?>" name="lng" id="register-lng">
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label>Country</label>
                    <select class="form-control second bg-white" name="country" required id="register-country">
                        <option value="0">Country</option>
                        <?php $__currentLoopData = countries(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option<?php echo ($user->country == $key)?' selected':''; ?> value="<?php echo $key; ?>"><?php echo $val; ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <i class="fa fa-chevron-down"></i>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label>Username</label>
                    <input class="form-control second bg-white" name="username" value="<?php echo $user->username; ?>">
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label>Password</label>
                    <input class="form-control second bg-white" name="password" type="password">
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label>Gender</label>
                    <select class="form-control second bg-white" name="gender" required>
                        <option value="1">Male</option>
                        <option value="2"<?php echo $user->gender === 2?' selected':''; ?>>Female</option>
                    </select>
                    <i class="fa fa-chevron-down"></i>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label>Preference</label>
                    <select class="form-control second bg-white" name="preference" required>
                        <option value="1">Male</option>
                        <option value="2"<?php echo $user->preference === 2?' selected':''; ?>>Female</option>
                        <option value="3"<?php echo $user->preference === 3?' selected':''; ?>>Male & Female</option>
                    </select>
                    <i class="fa fa-chevron-down"></i>
                </div>
            </div>
            <div class="col-md-12">
                <div class="form-group">
                    <label>Avatar</label>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="input-group mb-3">
                                <div class="custom-file">
                                    <input accept="image/*" type="file" class="custom-file-input" name="avatar" id="register-avatar" aria-describedby="register-avatar">
                                    <label class="custom-file-label" for="register-avatar">Choose file</label>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="register-upload-avatar">
                                <input type="hidden" id="x" value="" name="x">
                                <input type="hidden" id="y" value="" name="y">
                                <input type="hidden" id="w" value="" name="w">
                                <input type="hidden" id="h" value="" name="h">
                                <span class="clear-avatar">&times;</span>
                                <img id="register-upload-avatar" src="<?php echo avatar($user->avatar, $user->gender); ?>">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php
            $user_interests = collect($user->interests()->get())->pluck('id')->all();
            ?>
            <div class="col-md-12">
                <div class="form-group">
                    <label>Interests</label>
                    <input type="hidden" name="interests" value="<?php echo implode(',',$user_interests); ?>" id="register-interests-input" required>
                    <div class="row">
                        <?php $__currentLoopData = $interests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $interest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div data-id="<?php echo $interest->id; ?>" class="interest-item shadow text-center<?php echo in_array($interest->id, $user_interests)?' active':''; ?>">
                                <span class="fas fa-check-circle"></span>
                                <i class="<?php echo $interest->icon; ?>"></i>
                                <?php echo $interest->text; ?>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <div class="col-md-12">
                <div class="form-group">
                    <label>About Me</label>
                    <textarea rows="3" class="form-control bg-white"><?php echo $user->about; ?></textarea>
                </div>
            </div>
            <div class="col-md-12">
                <div class="form-group text-center">
                    <button class="btn btn-primary" type="submit">Save Changes</button>
                </div>
            </div>
        </div>
    </form>
</div>
<script>
    var uploadedImageURL = '<?php echo avatar($user->avatar, $user->gender); ?>';
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mycloudd/public_html/demo.myclouddate.com/secure/resources/views/users/setting.blade.php ENDPATH**/ ?>
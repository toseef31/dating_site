<div class="footer">
    <div class="container">
        <div class="text-center">
            <ul class="list-unstyled menu-footer clearfix mb-1">
                <li><a href="#">About</a></li>
                <li><a href="#">Blog</a></li>
                <li><a href="<?php echo route('landing'); ?>">Search</a></li>
                <li><a href="#">Terms</a></li>
                <li><a href="#">Privacy</a></li>
                <li><a href="#">Contact</a></li>
            </ul>
            <p class="mb-1">&copy; 2020 Singles Dating World</p>
        </div>
    </div>
</div>
<?php /**PATH D:\Xampp\htdocs\cloud\secure\resources\views/partials/footer.blade.php ENDPATH**/ ?>
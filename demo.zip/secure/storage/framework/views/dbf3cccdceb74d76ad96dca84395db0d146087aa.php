<?php $__env->startSection('title'); ?>
    <title><?php echo isset($page)?'Edit':'Add New';?> Page</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <h3><?php echo $page?'Edit':'Add New';?> Page</h3>
    <form action="" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <div class="form-group">
            <label>Title</label>
            <input class="form-control" name="title" value="<?php echo $page?$page->title:''; ?>">
        </div>
        <div class="form-group">
            <label>Content</label>
            <textarea rows="10" class="form-control" id="summernote" name="content"><?php echo $page?$page->content:''; ?></textarea>
        </div>
        <strong>SEO Optional</strong>
        <hr>
        <div class="form-group">
            <label>Keywords</label>
            <input class="form-control" name="keywords" value="<?php echo $page?$page->keywords:''; ?>">
        </div>
        <div class="form-group">
            <label>Description</label>
            <input class="form-control" name="description" value="<?php echo $page?$page->description:''; ?>">
        </div>
        <div class="form-group">
            <label>Picture</label>
            <input name="image" type="file" class="form-control">
        </div>
        <div class="form-group">
            <button class="btn btn-info">Save Page</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\cloud\secure\resources\views/admin/addpage.blade.php ENDPATH**/ ?>
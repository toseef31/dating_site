<li id="conversation-<?php echo $conv->id; ?>" data-id="<?php echo $conv->id; ?>" class="conversation-item<?php echo ( Illuminate\Support\Facades\Route::is('message') && request()->id ==  $conv->id) || (!request()->id && $key == 0) ? ' active':''; ?>">
    <div class="media">
        <?php if(auth()->id() === $conv->sender_id): ?>
            <img class="mr-2 border rounded-circle" src="<?php echo avatar($conv->receive->avatar, $conv->receive->gender); ?>">
        <?php else: ?>
            <img class="mr-2 border rounded-circle" src="<?php echo avatar($conv->sender->avatar, $conv->sender->gender); ?>">
        <?php endif; ?>
        <div class="media-body">
            <?php if(auth()->id() === $conv->sender_id): ?>
                <strong><?php echo fullname($conv->receive->firstname, $conv->receive->lastname, $conv->receive->username); ?></strong>
            <?php else: ?>
                <strong><?php echo fullname($conv->sender->firstname, $conv->receive->lastname, $conv->sender->username); ?></strong>
            <?php endif; ?>
            <p class="mb-0"><?php echo $conv->last_message; ?></p>
        </div>
    </div>
</li>
<?php /**PATH /home/mycloudd/public_html/demo.myclouddate.com/secure/resources/views/messages/item.blade.php ENDPATH**/ ?>
<?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-3">
        <div data-id="<?php echo $photo->id; ?>" data-url="<?php echo url($photo->file); ?>" class="photo-item view-photo border shadow" style="background-image: url('<?php echo url($photo->thumb); ?>')">
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /home/mycloudd/public_html/demo.myclouddate.com/secure/resources/views/photo/load.blade.php ENDPATH**/ ?>
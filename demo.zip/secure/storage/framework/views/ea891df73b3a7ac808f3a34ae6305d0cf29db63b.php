<?php $__env->startSection('title'); ?>
    <title>Edit User</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="users_section">
        <h2>Edit User</h2>
        <?php if($errors->any()): ?>
            <div class="alert alert-warning alert-dismissible fade show">
                <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $error; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo $item; ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <?php if(session()->has('success_update')): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <strong>Success:</strong> <?php echo session()->get('success_update'); ?>

                <?php echo session()->forget('success_update'); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>
        <form action="" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <div class="row">
                <div class="col-md-2">
                    <div class="user">
                        <span class="change-avatar"><i class="fas fa-camera"></i></span>
                        <span class="clear-avatar">&times;</span>
                        <?php
                        $avatar = avatar($user->avatar, $user->gender);
                        $age = Carbon\Carbon::parse($user->birthday)->age;
                        ?>
                        <div class="avatar-upload">
                            <input type="hidden" name="x" id="x">
                            <input type="hidden" name="y" id="y">
                            <input type="hidden" name="w" id="w">
                            <input type="hidden" name="h" id="h">
                        </div>
                        <div id="avatarPreview">
                            <img id="uploadPreview" src="<?php echo $avatar; ?>">
                        </div>
                        <input type="file" name="avatar" style="display: none" id="uploadImage" accept="image/jpeg">
                        <p class="text-center text-primary"><?php echo ($user->ip)?$user->ip:'No IP'; ?></p>
                        <p class="age">&#64;<?php echo $user->username; ?></p>
                        <p class="age"><?php echo $age; ?> - <?php echo countries($user->country); ?></p>
                    </div>
                    <button class="btn btn-success btn-block mt-2">Save</button>
                </div>
                <div class="col-md-10">
                    <div class="card">
                        <div class="card-header">Public Info</div>
                        <div class="card-body">
                            <div class="form-group">
                                <label>Fullname</label>
                                <input class="form-control" name="fullname" value="<?php echo $user->fullname; ?>">
                            </div>
                            <div class="form-group">
                                <label>Username</label>
                                <input class="form-control" name="username" value="<?php echo $user->username; ?>">
                            </div>
                            <div class="form-group">
                                <label>Email</label>
                                <input class="form-control" type="email" name="email" value="<?php echo $user->email; ?>">
                            </div>
                            <div class="form-group">
                                <label>Birthday</label>
                                <div class="row">
                                    <div class="col-md-4">
                                        <select name="day" class="form-control">
                                            <option value="">Day</option>
                                            <?php for($i=1; $i< 32; $i++): ?>
                                                <option<?php echo date('j', strtotime($user->birthday)) == $i?' selected':'';?> value="<?php echo strlen($i)==1?'0'.$i:$i; ?>"><?php echo strlen($i)==1?'0'.$i:$i; ?></option>
                                            <?php endfor; ?>
                                        </select>
                                    </div>
                                    <div class="col-md-4">
                                        <select name="month" class="form-control">
                                            <option value="">Month</option>
                                            <?php $__currentLoopData = months(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option<?php echo date('n', strtotime($user->birthday)) == $key+1?' selected':'';?> value="<?php echo strlen($key+1)==1?'0'.$key+1:$key+1; ?>"><?php echo $val; ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-md-4">
                                        <select name="year" class="form-control">
                                            <option value="">Year</option>
                                            <?php for($i=1920; $i <= date('Y'); $i++): ?>
                                                <option<?php echo date('Y', strtotime($user->birthday)) == $i?' selected':'';?> value="<?php echo $i; ?>"><?php echo $i; ?></option>
                                            <?php endfor; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Country</label>
                                <select class="form-control" name="country">
                                    <option value="">Select Country</option>
                                    <?php $__currentLoopData = countries(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option<?php echo $user->country == $key?' selected':'';?> value="<?php echo $key; ?>"><?php echo $val; ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>About</label>
                                <textarea class="form-control" name="about"><?php echo $user->about; ?></textarea>
                            </div>
                            <div class="form-group">
                                <label>Status</label>
                                <select class="form-control" name="active">
                                    <option<?php echo $user->active?'':' selected'; ?> value="0">Deactivate</option>
                                    <option<?php echo $user->active?' selected':''; ?> value="1">Active</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="card mt-3">
                        <div class="card-header">Change Password</div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Password</label>
                                        <input class="form-control" type="password" name="password">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Confirm Password</label>
                                        <input class="form-control" type="password" name="password_confirm">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
    <script>
        var uploadedImageURL = '<?php echo $avatar; ?>';
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\cloud\secure\resources\views/admin/user.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title'); ?>
    <title>Interests</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <h3 class="clearfix">Interests<button class="btn btn-info float-right" data-toggle="modal" data-target="#modal-add-interest"><i class="fas fa-plus"></i> Add New</button></h3>
    <div class="table-responsive mt-3">
        <table class="table table-bordered table-striped">
            <thead>
            <tr>
                <th>Icon</th>
                <th>Name</th>
                <th>Action</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $interests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $interest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr id="interest-<?php echo $interest->id; ?>">
                    <td class="icon">
                        <i class="<?php echo $interest->icon; ?>"></i>
                    </td>
                    <td class="name"><?php echo $interest->text; ?></td>
                    <td>
                        <button class="btn btn-info btn-sm edit-interest" data-toggle="modal" data-target="#modal-interest-<?php echo $interest->id; ?>" data-id="<?php echo $interest->id; ?>"><i class="fas fa-edit"></i> Edit</button>
                        <button class="btn btn-danger delete-interest" data-id="<?php echo $interest->id; ?>"><i class="fas fa-trash"></i> Delete</button>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php $__currentLoopData = $interests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $interest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="modal-interest-<?php echo $interest->id; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-sm" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Edit Interest</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form action="" class="editInterest">
                            <?php echo csrf_field(); ?>

                            <div class="form-group">
                                <label>Name</label>
                                <input name="id" value="<?php echo $interest->id; ?>" type="hidden">
                                <input name="action" value="update_interest" type="hidden">
                                <input class="form-control" name="text" value="<?php echo $interest->text; ?>">
                            </div>
                            <div class="form-group">
                                <label>Icon</label>
                                <input class="form-control" name="icon" value="<?php echo $interest->icon; ?>">
                            </div>
                            <div class="form-group">
                                <button class="btn btn-success btn-block" type="submit">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="modal fade" id="modal-add-interest" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Add Interest</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="" class="addInterest">
                        <?php echo csrf_field(); ?>

                        <div class="form-group">
                            <label>Name</label>
                            <input name="action" value="add_interest" type="hidden">
                            <input class="form-control" name="text" value="">
                        </div>
                        <div class="form-group">
                            <label>Icon</label>
                            <input class="form-control" name="icon" value="">
                        </div>
                        <div class="form-group">
                            <button class="btn btn-success btn-block" type="submit">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\cloud\secure\resources\views/admin/interests.blade.php ENDPATH**/ ?>
<div class="sidebar">
    <?php
    $logo = setting('logo_second');
    $logo = $logo ? url($logo) : url('assets/images/logo_white.png');
    ?>
    <p class="text-center logo mb-4">
        <a href="<?php echo url('/'); ?>"><img src="<?php echo $logo; ?>" class="img-fluid"></a>
    </p>
    <?php if(auth()->check()): ?>
        <?php
        $user = auth()->user();
        ?>
        <div class="p-3">
            <div class="text-center user-block text-white mb-3">
                <a href="<?php echo route('profile',['username'=>$user->username]); ?>"><img src="<?php echo avatar($user->avatar, $user->gender); ?>" class="w-75 rounded-circle mb-2"></a>
                <p class="font-weight-bold text-uppercase mb-0"><?php echo fullname($user->firstname, $user->lastname, $user->username); ?></p>
                <p style="font-size: 14px;"><i class="fas fa-map-marker-alt"></i> <?php echo fulladdress($user->address, $user->country); ?></p>
            </div>
        </div>
        <ul class="list-unstyled">
            <li><a class="<?php echo Illuminate\Support\Facades\Route::is('landing')?'active':''; ?>" href="<?php echo route('landing'); ?>">Browse <i class="fas fa-search"></i></a></li>
            <li><a class="<?php echo Illuminate\Support\Facades\Route::is('messages') || Illuminate\Support\Facades\Route::is('message')?'active':''; ?>" href="<?php echo route('messages'); ?>">Messages <i class="fas fa-comments"></i></a></li>
            <li><a class="<?php echo Illuminate\Support\Facades\Route::is('video')?'active':''; ?>" href="">Video Chat <i class="fas fa-video"></i></a></li>
            <li><a class="<?php echo Illuminate\Support\Facades\Route::is('setting')?'active':''; ?>" href="<?php echo route('setting'); ?>">Setting <i class="fas fa-cog"></i></a></li>
            <li><a href="<?php echo route('logout'); ?>">Logout <i class="fas fa-sign-out-alt"></i></a></li>
        </ul>
    <?php else: ?>
        <div class="text-center text-white p-3">
            <p class="text-uppercase font-weight-bold">Create an account</p>
            <form action="<?php echo route('quick_reg'); ?>" method="post" id="formQuick">
                <div class="form-group">
                    <input class="form-control form-control-sm" name="username" required placeholder="Username" id="register-username">
                </div>
                <div class="form-group">
                    <input class="form-control form-control-sm" type="password" name="password" required placeholder="Password" id="quick-pass">
                </div>
                <div class="form-group">
                    <select class="form-control form-control-sm" name="gender" id="quick-gender">
                        <option value="">Gender</option>
                        <option value="1">Male</option>
                        <option value="2">Female</option>
                    </select>
                    <i class="fa fa-chevron-down"></i>
                </div>
                <div class="form-group">
                    <input class="form-control form-control-sm" name="email" required placeholder="Email" type="email" id="register-email">
                </div>
                <div class="form-group">
                    <select class="form-control form-control-sm" name="country" id="quick-country">
                        <option value="">Location</option>
                        <?php $__currentLoopData = countries(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo $key; ?>"><?php echo $country; ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <i class="fa fa-chevron-down"></i>
                </div>
                <div class="form-group">
                    <button class="btn btn-gray btn-block btn-md" type="submit">Sign Up</button>
                </div>
                <p>OR</p>
                <a href="<?php echo route('loginfacebook'); ?>" class="btn btn-block btn-facebook btn-sm"><i class="fab fa-facebook-f"></i> Login with Facebook</a>
                <a href="<?php echo route('logintwitter'); ?>" class="btn btn-block btn-twitter btn-sm"><i class="fab fa-facebook-f"></i> Login with Twitter</a>
            </form>
        </div>
    <?php endif; ?>
</div>
<?php /**PATH /home/mycloudd/public_html/demo.myclouddate.com/secure/resources/views/partials/sidebar.blade.php ENDPATH**/ ?>
<div id="message-box-<?php echo $conversation->id; ?>" class="h-100">
    <div class="title-conversation">
        <?php echo auth()->id() === $conversation->sender_id ? fullname($conversation->receive->firstname, $conversation->receive->lastname, $conversation->receive->username) : fullname($conversation->sender->firstname, $conversation->sender->lastname, $conversation->sender->username); ?>

    </div>
    <div class="list-messages">
        <ul class="list-unstyled mb-0">
            <?php if($conversation->messages()->count()): ?>
                <?php if($conversation->messages()->count() > 20): ?>
                    <li class="load_more_message" data-id="<?php echo $conversation->id; ?>" data-page="1"><span>Load more</span></li>
                <?php endif; ?>
                <?php $__currentLoopData = collect($conversation->messages()->get()->take(20))->reverse(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $message->seen(); ?>

                    <?php echo $__env->make('messages.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </ul>
        <div class="write-message<?php echo auth()->id() == $conversation->sender_id && $conversation->waiting == 1 && !empty($conversation->last_message)?' waiting':''; ?>">
            <input data-id="<?php echo $conversation->id; ?>" placeholder="Type your message..." class="message-input">
        </div>
    </div>
</div>
<?php /**PATH /home/mycloudd/public_html/demo.myclouddate.com/secure/resources/views/messages/conversation.blade.php ENDPATH**/ ?>
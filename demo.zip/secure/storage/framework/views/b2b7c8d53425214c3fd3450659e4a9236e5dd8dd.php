<li class="message<?php echo auth()->id() == $message->user_id ? ' self':''; ?>" id="message-<?php echo $message->id; ?>">
    <img src="<?php echo avatar($message->user->avatar, $message->user->gender); ?>" class="avatar border rounded-circle mr-2">
    <div class="message-detail">
        <?php echo $message->message; ?>

        <p><?php echo \Carbon\Carbon::createFromTimestamp(strtotime($message->created_at))->diffForHumans(); ?></p>
    </div>
</li>
<?php /**PATH /home/mycloudd/public_html/demo.myclouddate.com/secure/resources/views/messages/message.blade.php ENDPATH**/ ?>
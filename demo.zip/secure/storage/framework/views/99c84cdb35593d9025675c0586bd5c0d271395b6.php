<div class="row position-relative">
    <span class="close-view-photo position-absolute">&times;</span>
    <div class="col-md-8">
        <div class="full_photo d-flex align-items-center"><img src="<?php echo url($photo->file); ?>"></div>
    </div>
    <div class="col-md-4 view-photo-right">
        <div class="content-photo">
            <div class="user-info">
                <div class="media">
                    <img src="<?php echo avatar($photo->user->avatar, $photo->user->gender); ?>">
                    <div class="media-body">
                        <h3 class="mb-0"><a href="<?php echo route('profile',['username'=>$photo->user->username]); ?>"><?php echo fullname($photo->user->firstname, $photo->user->lastname, $photo->user->username); ?></a></h3>
                        <?php if(auth()->check() && in_array($photo->user->id, collect(auth()->user()->follows()->get())->pluck('id')->all())): ?>
                            <span data-id="<?php echo $photo->user->id; ?>" class="badge badge-primary btn-follow"><i class="fas fa-check"></i> Followed</span>
                        <?php else: ?>
                            <span data-id="<?php echo $photo->user->id; ?>" class="badge badge-primary btn-follow">Follow</span>
                        <?php endif; ?>
                        <p>
                            <?php echo $photo->description; ?>

                        </p>
                    </div>
                </div>
            </div>
            <div class="comments">
                <ul class="list-unstyled m-0">
                    <?php if($photo->comments()->count()): ?>
                        <?php $__currentLoopData = $photo->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $__env->make('photo.comment', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
        <div class="photo-action">
            <div class="like-photo clearfix">
                <?php if($photo->likes()->count() && auth()->check() && in_array(auth()->id(), collect($photo->likes()->get())->pluck('id')->all())): ?>
                    <i class="fas fa-heart" data-id="<?php echo $photo->id; ?>" id="love-photo"></i>
                <?php else: ?>
                    <i class="far fa-heart" data-id="<?php echo $photo->id; ?>" id="love-photo"></i>
                <?php endif; ?>
                <span><?php echo $photo->likes()->count()?$photo->likes()->count():''; ?></span>
            </div>
            <textarea data-id="<?php echo $photo->id; ?>" class="write-comment" placeholder="Comment on this photo"></textarea>
        </div>
    </div>
</div>
<?php /**PATH /home/mycloudd/public_html/demo.myclouddate.com/secure/resources/views/photo/view.blade.php ENDPATH**/ ?>
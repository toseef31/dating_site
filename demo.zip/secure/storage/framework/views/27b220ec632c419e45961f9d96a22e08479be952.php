<?php $__env->startSection('title'); ?>
    <title>Users</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="users_section">
        <h2>Manage Users</h2>
        <div class="row mb-4">
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-2">
                    <div class="user effect<?php echo !$user->active?' suspended':'';?>">
                        <?php if(!$user->active): ?>
                            <span>Deactivated</span>
                        <?php endif; ?>
                        <?php
                        $avatar = avatar($user->avatar, $user->gender);
                        $age = Carbon\Carbon::parse($user->birthday)->age;
                        ?>
                        <a target="_blank" href="<?php echo route('profile',['username'=>$user->username]); ?>"><img src="<?php echo $avatar; ?>"></a>
                        <p class="text-center text-primary"><?php echo ($user->ip)?$user->ip:'No IP'; ?></p>
                        <p class="age">&#64;<?php echo $user->username; ?></p>
                        <p class="age"><?php echo $age; ?> - <?php echo countries($user->country); ?></p>
                        <div class="btn-group btn-block" role="group" aria-label="Basic example">
                            <?php if(!$user->is_admin): ?>
                            <a onclick="return confirm('Are you sure?')" type="button" class="btn btn-danger" href="<?php echo route('admindeleteuser',['id'=>$user->id]); ?>"><i class="fas fa-trash"></i> Delete</a>
                            <?php endif; ?>
                            <a type="button" class="btn btn-info" href="<?php echo route('adminedituser',['id'=>$user->id]); ?>"><i class="fas fa-edit"></i> Edit</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php echo $pages; ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\cloud\secure\resources\views/admin/users.blade.php ENDPATH**/ ?>
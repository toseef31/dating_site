<?php $__env->startSection('content'); ?>
    <div class="welcome overflow-hidden">
        <div class="container h-100 position-relative">
            <span class="position-absolute circle-1"></span>
            <span class="position-absolute circle-2"></span>
            <div class="row h-100">
                <div class="col-md-6 pt-5 d-none d-sm-block">
                    <?php
                        $home_background = setting('home_background');
                        $home_background = $home_background ? url($home_background) : url('assets/images/couple.png');
                    ?>
                    <img style="margin-top: calc(50% - 250px)" src="<?php echo $home_background; ?>">
                </div>
                <div class="col-md-6">
                    <div class="row" style="padding-top: calc(100% - 400px)">
                        <div class="col-md-9 mx-auto pt-5">
                            <?php if(session()->has('fail_login')): ?>
                            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                <strong>Warning!</strong> <?php echo session()->get('fail_login'); ?>

                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                                <?php echo e(session()->forget('fail_login')); ?>

                            <?php endif; ?>
                            <?php if($errors->any()): ?>
                                    <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                        <ul class="mb-0">
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php $__currentLoopData = $error; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo $item; ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                            <?php endif; ?>
                            <form method="post" action="">
                                <?php echo csrf_field(); ?>

                                <div class="form-group">
                                    <label>Username</label>
                                    <input class="form-control" type="text" required name="username">
                                </div>
                                <div class="form-group">
                                    <label>Password</label>
                                    <input class="form-control" type="password" required name="password">
                                </div>
                                <div class="form-group">
                                    <button class="btn btn-primary btn-block" type="submit">Login</button>
                                </div>
                            </form>
                            <p class="text-center mt-4 mb-4"><a href="<?php echo route('register'); ?>">Register</a></p>
                            <?php if(setting('social_login')): ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <a href="<?php echo route('loginfacebook'); ?>" class="btn btn-block btn-facebook btn-sm mb-2"><i class="fab fa-facebook-f"></i> Login with Facebook</a>
                                </div>
                                <div class="col-md-6">
                                    <a href="<?php echo route('logintwitter'); ?>" class="btn btn-block btn-twitter btn-sm mb-2"><i class="fab fa-twitter"></i> Login with Twitter</a>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\cloud\secure\resources\views/home.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta name="csrf_token" content="<?php echo csrf_token(); ?>">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://fonts.googleapis.com/css?family=Montserrat&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo url('assets/css/bootstrap.min.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo url('assets/css/fontawesome.min.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo url('assets/css/cropper.min.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo url('assets/css/app.css'); ?>">
    <script src="<?php echo url('assets/js/jquery.min.js'); ?>"></script>
    <script src="<?php echo url('assets/js/bootstrap.min.js'); ?>"></script>
    <script src="<?php echo url('assets/js/cropper.min.js'); ?>"></script>
    <?php
    $seo_website_title = setting('website_title');
    $seo_website_description = setting('website_description');
    $seo_website_tagline = setting('website_tagline');
    $seo_website_keywords = setting('website_keywords');
    $seo_social_image = setting('social_image');
    $seo_website_type = 'website';
    ?>
    <title><?php echo isset($seo_title) ? $seo_title.' - '.$seo_website_title : $seo_website_title; ?></title>
    <meta name="keywords" content="<?php echo isset($seo_keywords) ? $seo_keywords.','.$seo_website_keywords : $seo_website_keywords; ?>">
    <meta name="description" content="<?php echo isset($seo_description) ? $seo_description.','.$seo_website_description : $seo_website_description; ?>">
    <meta property="og:title" content="<?php echo isset($seo_title) ? $seo_title.' - '.$seo_website_title : $seo_website_title; ?>">
    <meta property="og:type" content="<?php echo isset($seo_type) ? $seo_type: $seo_website_type; ?>">
    <meta property="og:url" content="<?php echo request()->url(); ?>">
    <meta property="og:image" content="<?php echo isset($seo_image) ? $seo_image : url($seo_social_image); ?>">
    <meta property="og:site_name" content="<?php echo $seo_website_tagline; ?>">
    <meta property="og:description" content="<?php echo isset($seo_description) ? $seo_description.','.$seo_website_description : $seo_website_description; ?>">
    <?php echo $__env->yieldContent('stylesheet'); ?>
</head>
<body>
<div class="header text-center p-2">
    <?php
        $logo = setting('website_logo');
        $logo = $logo ? url($logo) : url('assets/images/logo.png');
    ?>
    <img src="<?php echo $logo; ?>">
</div>
<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    var ajax_url = '<?php echo route('ajax'); ?>';
</script>
<script src="<?php echo url('assets/js/app.js'); ?>"></script>
<?php echo $__env->yieldContent('javascript'); ?>
</body>
</html>
<?php /**PATH D:\Xampp\htdocs\cloud\secure\resources\views/layouts/welcome.blade.php ENDPATH**/ ?>
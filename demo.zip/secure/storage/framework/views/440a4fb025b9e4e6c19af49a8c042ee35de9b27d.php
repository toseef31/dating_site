<li>
    <div class="media">
        <img src="<?php echo avatar($comment->user->avatar, $comment->user->gender); ?>">
        <div class="media-body">
            <h3 class="font-weight-bold"><a href="<?php echo route('profile',['username'=>$comment->user->username]); ?>"><?php echo fullname($comment->user->fullname, $comment->user->username); ?></a></h3>
            <p>
                <?php echo $comment->comment; ?>

            </p>
        </div>
    </div>
</li>
<?php /**PATH /home/mycloudd/public_html/demo.myclouddate.com/secure/resources/views/photo/comment.blade.php ENDPATH**/ ?>
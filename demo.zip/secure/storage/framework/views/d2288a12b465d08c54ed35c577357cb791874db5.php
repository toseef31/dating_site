<?php if(count($users)): ?>
    <div class="row mb-3">
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3">
                <a href="<?php echo route('profile',['username'=>$user->username]); ?>">
                    <div class="user-item shadow-sm rounded effect" style="background-image: url('<?php echo avatar($user->avatar, $user->gender); ?>')">
                        <span class="photos"><i class="fas fa-camera"></i> <?php echo $user->photos()->count(); ?></span>
                        <span class="fullname"><?php echo fullname($user->fullname, $user->username); ?></span>
                        <span class="address"><?php echo fulladdress($user->address, $user->country); ?></span>
                    </div>
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php else: ?>
<?php endif; ?>
<?php echo $users->links(); ?>

<?php /**PATH D:\Xampp\htdocs\cloud\secure\resources\views/ajax_filter.blade.php ENDPATH**/ ?>
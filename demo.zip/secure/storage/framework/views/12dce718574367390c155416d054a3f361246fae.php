<!DOCTYPE html>
<html>
<head>
    <?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('stylesheet'); ?>
</head>
<body>
<div class="landing">
    <div class="container">
        <?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="main">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
    <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<script>
    var ajax_url = '<?php echo route('ajax'); ?>';
</script>
<script src="<?php echo url('assets/js/app.js'); ?>"></script>
<?php echo $__env->yieldContent('javascript'); ?>
</body>
</html>
<?php /**PATH /home/mycloudd/public_html/demo.myclouddate.com/secure/resources/views/layouts/default.blade.php ENDPATH**/ ?>
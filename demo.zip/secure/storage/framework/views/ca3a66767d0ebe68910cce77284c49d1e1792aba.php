<!DOCTYPE html>
<html>
<head>
    <?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('stylesheet'); ?>
</head>
<body>
<div class="header text-center p-2">
    <?php
        $logo = setting('website_logo');
        $logo = $logo ? url($logo) : url('assets/images/logo.png');
    ?>
    <img src="<?php echo $logo; ?>">
</div>
<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    var ajax_url = '<?php echo route('ajax'); ?>';
</script>
<script src="<?php echo url('assets/js/app.js'); ?>"></script>
<?php echo $__env->yieldContent('javascript'); ?>
</body>
</html>
<?php /**PATH /home/mycloudd/public_html/demo.myclouddate.com/secure/resources/views/layouts/welcome.blade.php ENDPATH**/ ?>